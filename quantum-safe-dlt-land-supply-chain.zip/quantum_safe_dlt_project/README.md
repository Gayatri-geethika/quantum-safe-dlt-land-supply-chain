# Quantum-Safe DLT for Land Records and Supply Chains

## Abstract

Quantum-Safe DLT for Land Records and Supply Chains is a secure distributed-ledger prototype designed to protect land ownership records and supply-chain transactions against future quantum-computing threats. The system combines a tamper-evident DLT-style ledger, standardized post-quantum ML-DSA digital signatures, and Qiskit-based quantum threat analysis. It supports secure transaction creation, signature verification, chained record integrity, and measurable security/performance evaluation. Qiskit is used to construct and simulate a Grover-style quantum search circuit to demonstrate how quantum algorithms change security assumptions. The prototype provides a practical bridge between blockchain/DLT security and quantum-safe migration.

## Problem

Traditional cryptographic systems used in digital records may face new security assumptions when large-scale fault-tolerant quantum computers become available. Land records and supply-chain transactions require long-term integrity, authenticity, and traceability.

## Proposed Solution

Our prototype provides:

1. Tamper-evident chained records.
2. Post-quantum ML-DSA-65 signatures.
3. Land-record transaction support.
4. Supply-chain transaction support.
5. Qiskit quantum-threat simulation.
6. Automated integrity and signature verification.
7. Benchmark metrics for signing and verification.

## Four Judging Criteria

### 1. Novelty

Our solution combines a quantum-safe distributed ledger for land records and supply chains with post-quantum signatures and Qiskit-based quantum threat analysis. It creates a practical bridge between decentralized record management and preparation for future quantum attacks.

### 2. Level of Qiskit Programming

Qiskit is used to construct a Grover-style quantum circuit, perform quantum simulation, measure output probabilities, and compare classical unstructured-search scale with the square-root quantum-search scale. The Qiskit module is integrated into the backend as a quantum-risk analysis endpoint.

### 3. Measurable Results / Metrics

The prototype measures ML-DSA signature size, average signing time, average verification time, verification success rate, Qiskit circuit depth, qubit count, measurement distribution, and simulated target-state probability. Results can be exported or presented in tables/graphs for judging.

### 4. Quantum Advantage

Grover's algorithm demonstrates the general quantum advantage for unstructured search: the query complexity changes from linear scale to approximately square-root scale. This does not mean that Grover directly breaks ML-DSA. Instead, the simulation demonstrates why cryptographic systems should be evaluated under changed quantum security assumptions.

## Architecture

```text
                 +----------------------+
                 |  Land Records API    |
                 +----------+-----------+
                            |
                 +----------v-----------+
                 |   DLT-style Ledger   |
                 | hash + previous hash |
                 +----------+-----------+
                            |
                 +----------v-----------+
                 |   ML-DSA-65 Signer   |
                 +----------+-----------+
                            |
          +-----------------+-----------------+
          |                                   |
+---------v----------+              +---------v----------+
| Supply Chain API   |              | Qiskit Threat Lab  |
| product transfers  |              | Grover simulation  |
+--------------------+              +--------------------+
```

## API Endpoints

- `GET /` — project information
- `POST /land-record` — create a land transaction
- `POST /supply-chain` — create a supply-chain transaction
- `GET /records` — view ledger records
- `GET /verify` — verify hashes, links, and signatures
- `GET /quantum-analysis` — run Qiskit analysis
- `GET /metrics` — run cryptographic benchmark

## Example Requests

### Land record

```json
{
  "property_id": "LAND-001",
  "owner": "Demo Owner",
  "location": "Vizianagaram"
}
```

### Supply chain

```json
{
  "product_id": "PROD-001",
  "manufacturer": "Demo Manufacturer",
  "location": "Vizianagaram"
}
```

## How to Run

```bash
python -m venv .venv
```

Activate the environment and install:

```bash
pip install -r requirements.txt
```

Run:

```bash
python app.py
```

The API will be available at:

```text
http://127.0.0.1:5000
```

## Important Technical Note

The Qiskit component is a controlled educational simulation of quantum search. It is not presented as a real-world attack against ML-DSA. ML-DSA is used as the post-quantum signature layer, while Qiskit demonstrates the quantum-threat reasoning used by the project.

## Future Scope

- Replace the in-memory ledger with a permissioned DLT.
- Add role-based access for land departments, buyers, sellers, manufacturers, and logistics partners.
- Store transactions in a database/IPFS-style storage layer.
- Add dashboards and automated graphs.
- Test additional post-quantum algorithms.
- Execute selected quantum circuits on quantum hardware when suitable.

## Team

Add team-member names and IDs here before submission.
