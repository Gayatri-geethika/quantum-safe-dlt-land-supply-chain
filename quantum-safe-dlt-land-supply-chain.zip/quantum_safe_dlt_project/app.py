from flask import Flask, jsonify, request
from ledger import QuantumSafeLedger
from quantum_analysis import run_quantum_threat_analysis
from metrics import benchmark_signature

app = Flask(__name__)
ledger = QuantumSafeLedger()

@app.get("/")
def home():
    return jsonify({
        "project": "Quantum-Safe DLT for Land Records and Supply Chains",
        "status": "running",
        "endpoints": [
            "POST /land-record",
            "POST /supply-chain",
            "GET /records",
            "GET /verify",
            "GET /quantum-analysis",
            "GET /metrics"
        ]
    })

@app.post("/land-record")
def add_land_record():
    data = request.get_json(silent=True) or {}
    required = ["property_id", "owner", "location"]
    missing = [x for x in required if x not in data]
    if missing:
        return jsonify({"error": f"Missing fields: {missing}"}), 400

    record = ledger.add_record("LAND", data)
    return jsonify(record), 201

@app.post("/supply-chain")
def add_supply_chain():
    data = request.get_json(silent=True) or {}
    required = ["product_id", "manufacturer", "location"]
    missing = [x for x in required if x not in data]
    if missing:
        return jsonify({"error": f"Missing fields: {missing}"}), 400

    record = ledger.add_record("SUPPLY_CHAIN", data)
    return jsonify(record), 201

@app.get("/records")
def records():
    return jsonify(ledger.records)

@app.get("/verify")
def verify():
    return jsonify(ledger.verify_chain())

@app.get("/quantum-analysis")
def quantum_analysis():
    return jsonify(run_quantum_threat_analysis())

@app.get("/metrics")
def metrics():
    return jsonify(benchmark_signature())

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
